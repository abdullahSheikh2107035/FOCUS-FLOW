//
//  BlockerView.swift
//  FocusFlow
//
//  Created by mustaahh on 14/4/26.
//


import SwiftUI

struct BlockerView: View {
    @ObservedObject var blockerVM: BlockerViewModel
    @State private var showAddWebsite = false
    @State private var newSiteName    = ""
    @State private var newSiteDomain  = ""
    @State private var expandedSection: ExpandedSection? = .websites

    enum ExpandedSection { case websites, apps, settings }

    var body: some View {
        NavigationStack {
            ZStack {
                LinearGradient(
                    colors: [Color(hex: "#0d1324"), Color(hex: "#12121f"), Color(hex: "#1a1a2e")],
                    startPoint: .topLeading, endPoint: .bottomTrailing
                )
                .ignoresSafeArea()

                ScrollView(showsIndicators: false) {
                    VStack(spacing: 16) {

                        // ── Master toggle card ────────────────────
                        MasterToggleCard(blockerVM: blockerVM)
                            .padding(.horizontal, 16)

                        // ── Strict mode card ──────────────────────
                        StrictModeCard(blockerVM: blockerVM)
                            .padding(.horizontal, 16)

                        // ── Website list ──────────────────────────
                        BlockerSection(
                            title: "Block Websites",
                            subtitle: "\(blockerVM.settings.enabledWebsiteCount) enabled",
                            icon: "globe.badge.chevron.backward",
                            isExpanded: expandedSection == .websites,
                            onToggle: { expandedSection = expandedSection == .websites ? nil : .websites }
                        ) {
                            VStack(spacing: 2) {
                                ForEach(blockerVM.settings.blockedWebsites) { site in
                                    WebsiteRow(site: site, isCustom: false) {
                                        blockerVM.toggleWebsite(site)
                                    } onDelete: { }
                                }

                                ForEach(blockerVM.settings.customWebsites) { site in
                                    WebsiteRow(site: site, isCustom: true) {
                                        blockerVM.toggleCustomWebsite(site)
                                    } onDelete: {
                                        blockerVM.removeCustomWebsite(site)
                                    }
                                }

                                // Add custom website
                                Button { showAddWebsite = true } label: {
                                    HStack(spacing: 10) {
                                        Image(systemName: "plus.circle.fill")
                                            .foregroundColor(.orange)
                                        Text("Add Website")
                                            .font(.subheadline)
                                            .foregroundColor(.orange)
                                        Spacer()
                                    }
                                    .padding(.horizontal, 14)
                                    .padding(.vertical, 10)
                                }
                            }
                        }
                        .padding(.horizontal, 16)

                        // ── App reminders ─────────────────────────
                        BlockerSection(
                            title: "App Reminders",
                            subtitle: "\(blockerVM.settings.enabledAppCount) selected",
                            icon: "iphone.slash",
                            isExpanded: expandedSection == .apps,
                            onToggle: { expandedSection = expandedSection == .apps ? nil : .apps }
                        ) {
                            VStack(spacing: 2) {
                                ForEach(blockerVM.settings.reminderApps) { app in
                                    AppReminderRow(app: app) {
                                        blockerVM.toggleReminderApp(app)
                                    }
                                }

                                // Phase 2 callout
                                Phase2Callout()
                                    .padding(.horizontal, 14)
                                    .padding(.vertical, 10)
                            }
                        }
                        .padding(.horizontal, 16)

                        // ── Penalty settings ──────────────────────
                        BlockerSection(
                            title: "Penalty Settings",
                            subtitle: "\(blockerVM.settings.exitPenaltyXP) XP on early exit",
                            icon: "bolt.badge.xmark.fill",
                            isExpanded: expandedSection == .settings,
                            onToggle: { expandedSection = expandedSection == .settings ? nil : .settings }
                        ) {
                            VStack(spacing: 12) {
                                PenaltyStepperRow(
                                    label: "Exit Delay",
                                    icon: "clock.badge.exclamationmark.fill",
                                    value: $blockerVM.settings.strictExitDelaySeconds,
                                    range: 3...30,
                                    step: 1,
                                    unit: "sec",
                                    color: .orange
                                ) { blockerVM.save() }

                                PenaltyStepperRow(
                                    label: "XP Penalty",
                                    icon: "bolt.badge.xmark.fill",
                                    value: $blockerVM.settings.exitPenaltyXP,
                                    range: 10...200,
                                    step: 10,
                                    unit: "XP",
                                    color: .red
                                ) { blockerVM.save() }

                                PenaltyToggleRow(
                                    label: "Show Shame Message",
                                    icon: "exclamationmark.bubble.fill",
                                    isOn: $blockerVM.settings.showShameMessage,
                                    color: .yellow
                                ) { blockerVM.save() }
                            }
                            .padding(.horizontal, 14)
                            .padding(.vertical, 4)
                        }
                        .padding(.horizontal, 16)

                        Spacer(minLength: 30)
                    }
                    .padding(.top, 8)
                }
            }
            .navigationTitle("Focus Blocker")
            .navigationBarTitleDisplayMode(.large)
            .toolbarBackground(Color(hex: "#12121f"), for: .navigationBar)
            .toolbarColorScheme(.dark, for: .navigationBar)
            .sheet(isPresented: $showAddWebsite) {
                AddWebsiteSheet(
                    name: $newSiteName,
                    domain: $newSiteDomain
                ) {
                    blockerVM.addCustomWebsite(name: newSiteName, domain: newSiteDomain)
                    newSiteName = ""; newSiteDomain = ""
                    showAddWebsite = false
                }
            }
        }
    }
}

// MARK: - Master Toggle Card

private struct MasterToggleCard: View {
    @ObservedObject var blockerVM: BlockerViewModel

    var body: some View {
        HStack(spacing: 16) {
            // Shield icon with pulse when active
            ZStack {
                Circle()
                    .fill(blockerVM.settings.isBlockerEnabled
                          ? Color.orange.opacity(0.2) : Color.white.opacity(0.06))
                    .frame(width: 56, height: 56)

                if blockerVM.isShieldActive {
                    Circle()
                        .stroke(Color.orange.opacity(0.4), lineWidth: 2)
                        .frame(width: 56, height: 56)
                        .scaleEffect(blockerVM.isShieldActive ? 1.15 : 1.0)
                        .animation(.easeInOut(duration: 1.2).repeatForever(), value: blockerVM.isShieldActive)
                }

                Image(systemName: blockerVM.isShieldActive ? "shield.fill" : "shield")
                    .font(.title2)
                    .foregroundColor(blockerVM.settings.isBlockerEnabled ? .orange : .gray)
            }

            VStack(alignment: .leading, spacing: 4) {
                Text(blockerVM.isShieldActive ? "Shield Active" : "Focus Blocker")
                    .font(.headline).fontWeight(.bold).foregroundColor(.white)
                Text(blockerVM.isShieldActive
                     ? "Blocking \(blockerVM.statusLabel) during session"
                     : blockerVM.settings.isBlockerEnabled
                         ? "Ready · \(blockerVM.statusLabel)"
                         : "Enable to block distractions")
                    .font(.caption).foregroundColor(.gray)
            }

            Spacer()

            Toggle("", isOn: Binding(
                get:  { blockerVM.settings.isBlockerEnabled },
                set:  { _ in blockerVM.toggleBlocker() }
            ))
            .tint(.orange)
            .labelsHidden()
        }
        .padding(16)
        .background(
            RoundedRectangle(cornerRadius: 18)
                .fill(blockerVM.settings.isBlockerEnabled
                      ? Color.orange.opacity(0.08) : Color.white.opacity(0.05))
                .overlay(RoundedRectangle(cornerRadius: 18)
                    .stroke(blockerVM.settings.isBlockerEnabled
                            ? Color.orange.opacity(0.3) : Color.white.opacity(0.08), lineWidth: 1.5))
        )
    }
}

// MARK: - Strict Mode Card

private struct StrictModeCard: View {
    @ObservedObject var blockerVM: BlockerViewModel

    var body: some View {
        VStack(spacing: 12) {
            HStack {
                Image(systemName: "lock.shield.fill")
                    .font(.headline)
                    .foregroundColor(blockerVM.settings.isStrictModeEnabled ? .red : .gray)
                    .padding(8)
                    .background((blockerVM.settings.isStrictModeEnabled ? Color.red : Color.white).opacity(0.12))
                    .clipShape(RoundedRectangle(cornerRadius: 8))

                VStack(alignment: .leading, spacing: 2) {
                    Text("Strict Mode")
                        .font(.subheadline).fontWeight(.semibold).foregroundColor(.white)
                    Text("Delays exit by \(blockerVM.settings.strictExitDelaySeconds)s · \(blockerVM.settings.exitPenaltyXP) XP penalty")
                        .font(.caption).foregroundColor(.gray)
                }

                Spacer()

                Toggle("", isOn: Binding(
                    get:  { blockerVM.settings.isStrictModeEnabled },
                    set:  { _ in blockerVM.toggleStrictMode() }
                ))
                .tint(.red)
                .labelsHidden()
                .disabled(!blockerVM.settings.isBlockerEnabled)
            }

            if blockerVM.settings.isStrictModeEnabled {
                HStack(spacing: 8) {
                    Image(systemName: "info.circle.fill").font(.caption).foregroundColor(.red.opacity(0.8))
                    Text("In strict mode, stopping the timer early shows a \(blockerVM.settings.strictExitDelaySeconds)-second countdown and deducts \(blockerVM.settings.exitPenaltyXP) XP.")
                        .font(.caption).foregroundColor(.gray)
                }
                .padding(10)
                .background(Color.red.opacity(0.08))
                .cornerRadius(10)
            }
        }
        .padding(14)
        .background(
            RoundedRectangle(cornerRadius: 16)
                .fill(Color.white.opacity(0.05))
                .overlay(RoundedRectangle(cornerRadius: 16)
                    .stroke(blockerVM.settings.isStrictModeEnabled
                            ? Color.red.opacity(0.3) : Color.white.opacity(0.08), lineWidth: 1))
        )
        .opacity(blockerVM.settings.isBlockerEnabled ? 1.0 : 0.45)
    }
}

// MARK: - Collapsible Section

private struct BlockerSection<Content: View>: View {
    let title: String
    let subtitle: String
    let icon: String
    let isExpanded: Bool
    let onToggle: () -> Void
    @ViewBuilder let content: () -> Content

    var body: some View {
        VStack(spacing: 0) {
            // Header
            Button(action: onToggle) {
                HStack(spacing: 12) {
                    Image(systemName: icon)
                        .font(.subheadline)
                        .foregroundColor(.orange)
                        .frame(width: 28)

                    VStack(alignment: .leading, spacing: 2) {
                        Text(title)
                            .font(.subheadline).fontWeight(.semibold).foregroundColor(.white)
                        Text(subtitle)
                            .font(.caption).foregroundColor(.gray)
                    }

                    Spacer()

                    Image(systemName: isExpanded ? "chevron.up" : "chevron.down")
                        .font(.caption).foregroundColor(.gray)
                }
                .padding(14)
            }

            if isExpanded {
                Divider().background(Color.white.opacity(0.08))
                content()
                    .padding(.bottom, 6)
            }
        }
        .background(
            RoundedRectangle(cornerRadius: 16)
                .fill(Color.white.opacity(0.05))
                .overlay(RoundedRectangle(cornerRadius: 16)
                    .stroke(Color.white.opacity(0.08), lineWidth: 1))
        )
        .animation(.easeInOut(duration: 0.2), value: isExpanded)
    }
}

// MARK: - Website Row

private struct WebsiteRow: View {
    let site: BlockedWebsite
    let isCustom: Bool
    let onToggle: () -> Void
    let onDelete: () -> Void

    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: site.icon)
                .font(.subheadline)
                .foregroundColor(site.isEnabled ? .orange : .gray)
                .frame(width: 28)

            VStack(alignment: .leading, spacing: 2) {
                Text(site.name)
                    .font(.subheadline).foregroundColor(site.isEnabled ? .white : .gray)
                Text(site.displayURL)
                    .font(.caption2).foregroundColor(.gray)
            }

            Spacer()

            if isCustom {
                Button(action: onDelete) {
                    Image(systemName: "minus.circle.fill")
                        .foregroundColor(.red.opacity(0.7))
                        .font(.subheadline)
                }
                .padding(.trailing, 4)
            }

            Toggle("", isOn: Binding(get: { site.isEnabled }, set: { _ in onToggle() }))
                .tint(.orange).labelsHidden()
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 9)
        .background(Color.white.opacity(site.isEnabled ? 0.03 : 0.0))
    }
}

// MARK: - App Reminder Row

private struct AppReminderRow: View {
    let app: ReminderApp
    let onToggle: () -> Void

    var body: some View {
        HStack(spacing: 12) {
            ZStack {
                RoundedRectangle(cornerRadius: 8)
                    .fill(Color(hex: app.colorHex).opacity(0.25))
                    .frame(width: 32, height: 32)
                Image(systemName: app.icon)
                    .font(.subheadline)
                    .foregroundColor(Color(hex: app.colorHex))
            }

            Text(app.name)
                .font(.subheadline).foregroundColor(app.isEnabled ? .white : .gray)

            Spacer()

            Toggle("", isOn: Binding(get: { app.isEnabled }, set: { _ in onToggle() }))
                .tint(.orange).labelsHidden()
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 9)
    }
}

// MARK: - Phase 2 Callout

private struct Phase2Callout: View {
    var body: some View {
        HStack(spacing: 10) {
            Image(systemName: "lock.square.stack.fill")
                .foregroundColor(.purple).font(.subheadline)
            VStack(alignment: .leading, spacing: 2) {
                Text("Real App Blocking — Coming in Phase 2")
                    .font(.caption).fontWeight(.semibold).foregroundColor(.white)
                Text("Requires Apple Screen Time entitlement. These are reminder targets only.")
                    .font(.caption2).foregroundColor(.gray)
            }
        }
        .padding(10)
        .background(Color.purple.opacity(0.08))
        .overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.purple.opacity(0.2), lineWidth: 1))
        .cornerRadius(10)
    }
}

// MARK: - Add Website Sheet

private struct AddWebsiteSheet: View {
    @Binding var name: String
    @Binding var domain: String
    let onAdd: () -> Void
    @Environment(\.dismiss) var dismiss

    var body: some View {
        NavigationStack {
            ZStack {
                Color(hex: "#12121f").ignoresSafeArea()

                VStack(spacing: 20) {
                    VStack(alignment: .leading, spacing: 8) {
                        Label("Site Name", systemImage: "textformat").font(.caption).foregroundColor(.gray)
                        TextField("e.g. Hacker News", text: $name)
                            .foregroundColor(.white).padding(12)
                            .background(Color.white.opacity(0.07)).cornerRadius(10)
                    }

                    VStack(alignment: .leading, spacing: 8) {
                        Label("Domain", systemImage: "globe").font(.caption).foregroundColor(.gray)
                        TextField("e.g. news.ycombinator.com", text: $domain)
                            .foregroundColor(.white).padding(12)
                            .background(Color.white.opacity(0.07)).cornerRadius(10)
                            .keyboardType(.URL)
                            .autocapitalization(.none)
                    }

                    Spacer()

                    Button(action: onAdd) {
                        Label("Add to Blocklist", systemImage: "plus.circle.fill")
                            .font(.headline).foregroundColor(.white)
                            .frame(maxWidth: .infinity).padding(.vertical, 14)
                            .background(domain.isEmpty ? Color.gray.opacity(0.3) : Color.orange)
                            .cornerRadius(14)
                    }
                    .disabled(domain.isEmpty)
                }
                .padding(16)
            }
            .navigationTitle("Add Website")
            .navigationBarTitleDisplayMode(.inline)
            .toolbarBackground(Color(hex: "#12121f"), for: .navigationBar)
            .toolbarColorScheme(.dark, for: .navigationBar)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }.foregroundColor(.gray)
                }
            }
        }
    }
}

// MARK: - Penalty stepper / toggle rows (local to BlockerView)

private struct PenaltyStepperRow: View {
    let label: String; let icon: String
    @Binding var value: Int
    let range: ClosedRange<Int>; let step: Int; let unit: String; let color: Color
    let onChange: () -> Void

    var body: some View {
        HStack {
            Image(systemName: icon).foregroundColor(color).frame(width: 28)
            Text(label).font(.subheadline).foregroundColor(.white)
            Spacer()
            Text("\(value) \(unit)").font(.subheadline).foregroundColor(.gray).frame(minWidth: 60, alignment: .trailing)
            Stepper("", value: $value, in: range, step: step)
                .labelsHidden()
                .onChange(of: value) { _ in onChange() }
        }
        .padding(.vertical, 6)
    }
}

private struct PenaltyToggleRow: View {
    let label: String; let icon: String
    @Binding var isOn: Bool
    let color: Color; let onChange: () -> Void

    var body: some View {
        HStack {
            Image(systemName: icon).foregroundColor(color).frame(width: 28)
            Text(label).font(.subheadline).foregroundColor(.white)
            Spacer()
            Toggle("", isOn: $isOn)
                .tint(color).labelsHidden()
                .onChange(of: isOn) { _ in onChange() }
        }
        .padding(.vertical, 6)
    }
}
