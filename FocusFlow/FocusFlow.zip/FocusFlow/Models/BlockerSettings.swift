//
//  BlockerSettings.swift
//  FocusFlow
//
//  Created by mustaahh on 14/4/26.
//
import Foundation
// MARK: - Blocked Website

struct BlockedWebsite: Identifiable, Codable, Equatable {
    var id: String = UUID().uuidString
    var name: String
    var domain: String          // e.g. "youtube.com"
    var icon: String            // SF Symbol name
    var isEnabled: Bool = true

    var displayURL: String { "www.\(domain)" }
}

// MARK: - Reminder App (display only — no actual blocking without entitlement)

struct ReminderApp: Identifiable, Codable, Equatable {
    var id: String = UUID().uuidString
    var name: String
    var icon: String            // SF Symbol name
    var colorHex: String
    var isEnabled: Bool = true
}

// MARK: - BlockerSettings

struct BlockerSettings: Codable {

    // Master switches
    var isBlockerEnabled: Bool   = false
    var isStrictModeEnabled: Bool = false

    // Strict mode behaviour
    var strictExitDelaySeconds: Int = 10   // countdown before user can force-exit
    var exitPenaltyXP: Int          = 50   // XP deducted for abandoning in strict mode
    var showShameMessage: Bool      = true // show motivational guilt message

    // Blocked websites (shown as reminder list; real blocking via Screen Time in Phase 2)
    var blockedWebsites: [BlockedWebsite] = BlockerSettings.defaultWebsites

    // Reminder apps
    var reminderApps: [ReminderApp] = BlockerSettings.defaultApps

    // Custom entries
    var customWebsites: [BlockedWebsite] = []

    // MARK: - Computed

    var allEnabledWebsites: [BlockedWebsite] {
        (blockedWebsites + customWebsites).filter { $0.isEnabled }
    }

    var enabledWebsiteCount: Int { allEnabledWebsites.count }
    var enabledAppCount: Int { reminderApps.filter { $0.isEnabled }.count }

    // MARK: - Defaults

    static let defaultWebsites: [BlockedWebsite] = [
        BlockedWebsite(name: "YouTube",      domain: "youtube.com",    icon: "play.rectangle.fill"),
        BlockedWebsite(name: "Facebook",     domain: "facebook.com",   icon: "person.2.fill"),
        BlockedWebsite(name: "Instagram",    domain: "instagram.com",  icon: "camera.fill"),
        BlockedWebsite(name: "Twitter / X",  domain: "twitter.com",    icon: "bird.fill"),
        BlockedWebsite(name: "TikTok",       domain: "tiktok.com",     icon: "music.note"),
        BlockedWebsite(name: "Reddit",       domain: "reddit.com",     icon: "text.bubble.fill"),
        BlockedWebsite(name: "Netflix",      domain: "netflix.com",    icon: "film.fill"),
        BlockedWebsite(name: "WhatsApp Web", domain: "web.whatsapp.com", icon: "message.fill"),
        BlockedWebsite(name: "Amazon",       domain: "amazon.com",     icon: "cart.fill"),
        BlockedWebsite(name: "ESPN",         domain: "espn.com",       icon: "sportscourt.fill"),
    ]

    static let defaultApps: [ReminderApp] = [
        ReminderApp(name: "YouTube",   icon: "play.rectangle.fill", colorHex: "#FF0000"),
        ReminderApp(name: "Instagram", icon: "camera.fill",         colorHex: "#C13584"),
        ReminderApp(name: "TikTok",    icon: "music.note",          colorHex: "#010101"),
        ReminderApp(name: "Twitter/X", icon: "bird.fill",           colorHex: "#1DA1F2"),
        ReminderApp(name: "Messages",  icon: "message.fill",        colorHex: "#34C759"),
        ReminderApp(name: "Reddit",    icon: "text.bubble.fill",    colorHex: "#FF4500"),
    ]

    // MARK: - UserDefaults persistence

    private static let key = "focusflow_blocker_settings"

    static func load() -> BlockerSettings {
        guard let data = UserDefaults.standard.data(forKey: key),
              let decoded = try? JSONDecoder().decode(BlockerSettings.self, from: data)
        else { return BlockerSettings() }
        return decoded
    }

    func save() {
        guard let data = try? JSONEncoder().encode(self) else { return }
        UserDefaults.standard.set(data, forKey: BlockerSettings.key)
    }
}
